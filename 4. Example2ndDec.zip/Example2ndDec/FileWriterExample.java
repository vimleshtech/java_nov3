package Example2ndDec;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterExample {

	public static void main(String[] args) throws IOException {
	
		//true : append data in existing file 
		FileWriter fw =new FileWriter("C:\\Users\\vkumar15\\Desktop\\Selenium\\out2.txt",true);
		BufferedWriter bw =new BufferedWriter(fw);
		
		bw.write("Hi, this is my first text writer code");
		bw.newLine();
		bw.write("test ...");
		
		
		bw.close();
		fw.close(); //save the file and close the instance 
		
		System.out.println("file is created..");
		
		
	}

}
