package Example2ndDec;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnectionExample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		
		//register or load the driver / sql connector 
		Class.forName("com.mysql.jdbc.Driver");
		
		//establish the connection from java to database 
		Connection con  = DriverManager.getConnection("jdbc:mysql://localhost/java", "root", "root");
		//link sql statement to connnection 
		Statement st = con.createStatement();
		//execute the sql command 
		ResultSet rs =	st.executeQuery("select * from emp;");
	
		//rs.getMetaData()
		
		System.out.println("salary\tname");
		while( rs.next())
		{
			System.out.println(rs.getString(3)+"\t"+rs.getString(2));
		}
		
		

	}

}
