package example;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestClass1 {
  	
  @Test(priority=2,groups= {"home"})
  public void search() 
  {	
	  System.out.println("search-1");
  }
  
  @Test(priority=1,groups= {"search"})
  public void open_browser()
  {
	  System.out.println("open..");
  }
  

  @Test(priority=4,groups= {"home","search"})
  public void test1()
  {
	  System.out.println("open..test1");
  }
  
  
  

  @Test(priority=5,groups= {"home"})
  public void test2()
  {
	  System.out.println("open..test2");
  }
  
  @Test(priority=3,enabled=false,groups= {"home"})
  public void close_browser()
  {
	  System.out.println("close..");
  }
  
  @BeforeMethod
  public void before_method() 
  {
	  
	  System.out.println("before method");
  }
  
  @AfterMethod
  public void afer_method()
  {
	  System.out.println("after method");
  }
  
  
  ///
  @BeforeClass
  public void bc()
  {
	  System.out.println("before class");
  }
  @AfterClass
  public void ac()
  {
	  System.out.println("after class");
  }
	  
  @BeforeTest
  public void bt() 
  {
	System.out.println("before test");  
	  
  }
  @AfterTest
  public void at()
  {
	  System.out.println("after test");
  }
  
  @BeforeSuite
  public void beforeSuite()
  {
	  System.out.println("before suite");
  }
  @AfterSuite
  public void afterSuite()
  {
	  System.out.println("after suite");
  }
}
