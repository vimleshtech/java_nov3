package example;

import org.testng.annotations.Test;

public class TestClass3 {
  @Test
  public void f() {
  }
}
