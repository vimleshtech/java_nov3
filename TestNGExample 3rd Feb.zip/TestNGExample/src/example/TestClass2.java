package example;

import org.testng.annotations.Test;

public class TestClass2 {
  @Test
  public void f() {
  }
}
