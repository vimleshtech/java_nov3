package example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Startup {

	public static void main(String[] args) {
				
		WebDriver drv = new ChromeDriver();
		drv.get("https://www.google.com/");
		
		String title = drv.getTitle();
		System.out.println("Page tile is = "+title);
		
		
		String url = drv.getCurrentUrl();
		System.out.println(url);
		
		//get page source code
		String src = drv.getPageSource();
		System.out.println(src);
		
		
		drv.findElement(By.name("q")).sendKeys("selenium jar file");
		
		drv.findElement(By.name("q")).sendKeys(Keys.ENTER);
		
		
		
		//refress the web page 
		//drv.navigate().refresh();
		
		//drv.navigate().back();
		//drv.navigate().forward();
		
		
		//close the open browser 
		//drv.close();
		
		
		
	}

}
