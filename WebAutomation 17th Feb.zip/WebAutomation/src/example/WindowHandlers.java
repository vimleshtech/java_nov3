package example;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandlers {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.naukri.com/");
		
		Set<String> wins = 	driver.getWindowHandles();
				
		System.out.println(wins.size());
		//read title of every window
		//for(int i=0; i<wins.size();i++)
		for(String win : wins)
		{
			driver.switchTo().window(win);
			String title  = driver.getTitle();
			System.out.println(title);
			
			if(title.startsWith("Jobs - Recruitment"))
			{
				driver.findElement(By.id("login_Layer")).click();
				
			}
			else
			{
				driver.close();
				//driver.quit(); //close all
			}
		}

	}

}
