package example;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.io.File;
import java.io.IOException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;


public class ScreenshotExample {

	public static void main(String[] args) throws IOException {

		
		WebDriver driver = new ChromeDriver();		
		driver.get("http://www.google.com");		
		
		/*
		int a=1;
		long b=1;		
		b =a;		
		//type casting / conversion 
		a =(int)b;
		*/
		
		File src = 	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File("C:\\Users\\Tech Vision\\Desktop\\exe\\out.png"));
		
		
	}

}
