package example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();		
		driver.get("http://www.gmail.com");		
		
		driver.findElement(By.linkText("Gmail")).click();
		
		//Thread.sleep(30000);  //wait for 10 secs
		
		//driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[5]/ul/li[2]/a")).click();
		driver.findElement(By.id("identifierId")).sendKeys("aba");
		driver.findElement(By.id("identifierNext")).click();
		Thread.sleep(30000);  //wait for 10 secs
		
		driver.findElement(By.name("password")).sendKeys("abc");
		//driver.findElement(By.id(""))
		
	
	}
	

}
