package objectDriven;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FacebookTestcase {
  
 
  private static Properties prop=null;
	 
  static WebDriver driver =null;
  
  @BeforeTest
  public void beforeClass()
  {
	  prop  = ObjectReader.readObjects();
	
	  driver=new ChromeDriver();
	  driver.get(prop.getProperty("url"));
  }
	
  @Test
  public void f() {
	  
	  //driver.findElement(By.name(prop.getProperty("uid"))).sendKeys("test");
	  
	 WebElement el = WebAction.getElement(driver, "name", prop.getProperty("uid"));
	 WebAction.perfomAction(el, "SENDKEYS", "test");
	 
  }
}
