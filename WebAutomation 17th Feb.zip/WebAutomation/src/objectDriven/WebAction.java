package objectDriven;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebAction {

	
	public static WebElement getElement(WebDriver driver, String key, String val)
	{
		WebElement el=null;
		
		key = key.toUpperCase().trim();
		switch (key) {
		case "ID":
			el = driver.findElement(By.id(val));
			
			break;
		case "NAME":
			el = driver.findElement(By.name(val));
			break;
		case "XPATH":
			el = driver.findElement(By.xpath(val));
			break;
		case "CSSSELECTOR":
			el = driver.findElement(By.cssSelector(val));
			break;
		case "CLASSNAME":
			el = driver.findElement(By.className(val));
			break;

		default:
			break;
		}
		
		return el;
		
	}
	

	public static String perfomAction(WebElement el, String key, String val)
	{
		
		String data="";
		
		key = key.toUpperCase();
		switch (key) {
		case "SENDKEYS":
			el.clear();
			el.sendKeys(val);
			
			break;
		case "CLICK":
			el.click();
			break;
		case "CLEAR":
			el.clear();
			break;
		case "ENTER":
			el.sendKeys(Keys.ENTER);
			break;
		case "TAB":
			el.sendKeys(Keys.TAB);
			break;

		case "GETTEXT":
			data = el.getText();
			
		default:
			break;
		}
		
		return data;
		
	}
	
}
