package objectDriven;

import java.io.FileInputStream;
import java.util.Properties;

public class ObjectReader {

	
	
	public static Properties readObjects()// main(String[] a)
	{
		Properties prop =null;
		
		try
		{
			FileInputStream fs = new FileInputStream("C:\\Users\\Tech Vision\\eclipse-workspace\\WebAutomation\\src\\objectDriven\\Objects.properties");
		
			 prop = new Properties();
			prop.load(fs);
			
			//System.out.println(prop.getProperty("url"));
			//System.out.println(prop.getProperty("uid"));
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return prop;
		
	}
}
