package objectDriven;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookLogin {

	public static void main(String[] args) {
		
		
		String data[][] = ExcelReader.readExcel();
		Properties prop = ObjectReader.readObjects();
		
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		
		//driver.findElement(By.name("email")).sendKeys(data[0][0]);		
		//driver.findElement(By.name("pass")).sendKeys(data[0][1]);
		
		 
	WebElement el =	WebAction.getElement(driver, data[0][3], prop.getProperty("uid"));
	WebAction.perfomAction(el, data[0][3], data[0][0]);
	
		
	}

}
