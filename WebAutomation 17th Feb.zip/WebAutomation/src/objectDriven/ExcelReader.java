package objectDriven;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelReader {

	public static String[][]  readExcel()//(String[] args) 
	{
		// TODO Auto-generated method stub

		String data[][] =null;
		
		try
		{			
			FileInputStream fs = new FileInputStream("C:\\Users\\Tech Vision\\Desktop\\WebProject00\\TestData.xls");
			
			HSSFWorkbook book = new HSSFWorkbook(fs);
			HSSFSheet sheet = book.getSheetAt(0);
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets();
			rc = sheet.getPhysicalNumberOfRows();
			cc = sheet.getRow(0).getPhysicalNumberOfCells();
			
			//System.out.println(sc);
			//System.out.println(rc);
			//System.out.println(cc);

			String uid,pwd,act,ky;
			data = new String[rc-1][cc];
			
			for(int i=1; i<rc;i++)
			{
				HSSFRow row  = sheet.getRow(i);
				HSSFCell cell = row.getCell(0);//first col
				uid = cell.getStringCellValue();
				
				
				cell = row.getCell(1);
				pwd = cell.getStringCellValue();
				
				cell = row.getCell(2);
				act = cell.getStringCellValue();
				
				cell = row.getCell(3);
				ky=cell.getStringCellValue();
				
				
				//System.out.println(uid+","+pwd+","+act+","+ky);
				data[i-1][0] = uid;
				data[i-1][1] = pwd;
				data[i-1][2] = act;
				data[i-1][3] = ky;
				
			}
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		return data;
	}

}
