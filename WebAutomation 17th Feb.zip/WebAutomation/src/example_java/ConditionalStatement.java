package example_java;

public class ConditionalStatement {

	public static void main(String[] args) {
		
		
			int n1,n2;
			
			n1 =440;
			n2 =99;
			
			//show greater no
			if (n1>n2)
			{
				System.out.println("n1 is greater");
			}
			else
			{
				System.out.println("n2 is greater");
			}
			
			//check even and odd numbers
			n1 =88;
			if(n1%2==0)
			{
				System.out.println("even no");
			}
			else
			{
				System.out.println("odd no");
			}
			
			///if else if else if ... else
			int a,b,c;
			a =55;
			b =67;
			c =90;
			
			if(a>b && a>c)
			{
				System.out.println("a is greater");
			}
			else if(b>c && b>c)
			{
				System.out.println("b is greater");
			}
			else
			{
				System.out.println("c is greater ");
			}
	}

}
