package example_java;

import java.util.Scanner;

public class LoopExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Loop : is iterator or repeation of statement
		 * Example : 
		 * 1 2 3 ..100
		 * init     =1
		 * condition  =100
		 * increment  = +1
		 * 
		 * Types :
		 * -while
		 * -for
		 * -do while
		 * -advance loop
		 */
		
		Scanner sc =new Scanner(System.in);
		String name;
		int n;
		
		
		
	
		
		for(int i=0; i<10;i++)
		{
			System.out.println(i);
			System.out.println("enter data :");
			name = sc.nextLine(); //string 
			
			System.out.println("enter id ");
			n = sc.nextInt(); //number 
			
			System.out.println("name is :"+name);
			System.out.println("id is  :"+n);
			
			
		}
		
		//in reverse order
		for(int i=90; i>0;i--)
		{
			System.out.println(i);
		}
	}

}
