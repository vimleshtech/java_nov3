package example_java;

import java.util.Scanner;

public class InputAndOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc =new Scanner(System.in);
		String name;
		int n;
		
		System.out.println("enter data :");
		name = sc.nextLine(); //string 
		
		System.out.println("enter id ");
		n = sc.nextInt(); //number 
		
		System.out.println("name is :"+name);
		System.out.println("id is  :"+n);
		

	}

}
