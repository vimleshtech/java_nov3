package example_java;

public class Basics {

	public static void main(String[] args) {


		/* Declartion of variable */
		//numiric - without decimal
		byte b =1; //1 byte
		short s =333;  //2  byte
		int i =333333;  //4 byte
		long l =44455555555l; //8 byte
		
		System.out.println(b); 
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		//numeric with decimal 
		float f =4444.555f;  //4 byte
		double d =44555.33434444; //8byte
		
		System.out.println(f);
		System.out.println(d);
		
		
		//alpha numeric 
		char c ='a';  //2 byte
		String ss ="Raman sinha 33j3hhg444";
		System.out.println(c);
		System.out.println(ss);
				
		//boolean
		boolean b1 = true; //1 byte 
		System.out.println(b1);

	}

}
