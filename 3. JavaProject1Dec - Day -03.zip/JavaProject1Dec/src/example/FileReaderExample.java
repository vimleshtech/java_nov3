package example;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReaderExample {

	public static void main(String[] args) throws IOException {

		String path;
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter path :");
		path  = sc.nextLine();
		
		//read file from physical location to buffer (JVM) 
		//FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\Selenium\\1. Java Session -01.txt");
		FileReader fr =new FileReader(path);
		//    \\  or  /
		//read data from jvm to byte code 
		//System.out.println(fr);
		BufferedReader br =new BufferedReader(fr);
		
		String d;
		
		while ( (d = br.readLine()) != null )
		{
			System.out.println(d);
		}
		
		
		
		

	}

}
