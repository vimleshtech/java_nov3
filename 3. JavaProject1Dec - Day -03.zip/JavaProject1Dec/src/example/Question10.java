package example;

public class Question10 {

	public static void main(String[] args) {
	
		int unit=20;
		double total =0;
		
		
		if(unit<=100)
		{
			total = unit*.40;
		}
		else if(unit<=300)
		{
			total = 40+  (unit-100)*.50;
		}
		else
		{
			total = 140+  (unit-300)*.60;
		}
		
		total = total+50;
		System.out.println("total cost is "+total);
		
		
		
		//q. B13
		char c='a';
		int n = c;
		System.out.println(n);
		
		if(n>=97 && n<=123) //from a to z
		{
			System.out.println("small case ");
		}
		else if(n>=65 && n<=91) // from A to Z
		{
			System.out.println("captical letter");
		}
		else if(n>=48 && n<=57) // from 0 to 9
		{
			System.out.println("digit"); 
		}
		else if(n ==13 || n == 32 || n == 59 )
		{
			System.out.println("other char");
		}
		
	}

}
