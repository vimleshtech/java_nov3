package example;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {

		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("etner your choice : ");
		int ch=sc.nextInt();
		
		int a=33,b=44;
		//345 =543
		
		switch(ch)
		{		
			case 1:
				System.out.println(a+b);
				break;
			case 2:
				System.out.println(a-b);
				break;
			case 3:
				System.out.println(a*b);
				break;
			case 4:
				System.out.println(a/b);
				break;
			case 5:
				System.out.println(a%b);
				break;
			default :
				System.out.println("no match");
				break;
				
		}
		

	}

}
