package example;

import java.util.Scanner;

public class ReverseNo {

	public static void main(String[] args) {
	
		Scanner sc =new Scanner(System.in);
		int n,a,b,c;
		System.out.println("enter data : ");
		n = sc.nextInt();
		
		a = n/100;  //345 = 3
		b = (n/10)%10;    // 34   = 4
		c = n%10;     // 5
		
		System.out.print(c);
		System.out.print(b);
		System.out.print(a);
		
		sc.close();
		
		
		

	}

}
