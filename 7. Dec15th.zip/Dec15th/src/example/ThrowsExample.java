package example;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsExample {

	public static void main(String[] args) throws FileNotFoundException {

		FileReader fr  =new FileReader("C:\\Users\\vkumar151\\Desktop\\Manaul Testing -11th Dec.txt");
		
		

	}

}
