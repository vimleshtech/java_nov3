package example;

import javax.xml.bind.SchemaOutputResolver;

public class Questions {

	public static void main(String[] args) {
	
		String str  ="Raman Sinha";
					//out ="namar ahnis"

		String ns[] = str.split(" ");//{"Raman","Sinha"}
		
		for(String w: ns)
		{
			for(int i=w.length()-1; i>=0; i--)//4 to 0 
			{
				System.out.print(w.charAt(i));
			}
			System.out.print(" ");
			
		}

		try{


		}
		catch(ArrayIndexOutOfBoundsException ex)
		{


		}
		catch(Exception ex)
		{

		}
		
		
		////
		try
		{

		}
		finally{

		}


		//
		try
		{

		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally{

		}


		
	}

}
