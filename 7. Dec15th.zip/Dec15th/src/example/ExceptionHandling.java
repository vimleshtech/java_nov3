package example;


import java.util.Scanner;

public class ExceptionHandling {

	public static void main(String[] args) {
	
		
		Scanner sc =new Scanner(System.in);
		int n,d,o;
		
		System.out.println("enter data : ");
		n = sc.nextInt();
		
		System.out.println("enter data : ");
		d = sc.nextInt();
		
		int dd[] = {111,222,33};
		
		//div
		try
		{
				
				if(d<0)
				{
					Exception ex = new Exception("Divisor cannot be less than 0");
					throw ex;
				}
				if(d>n)
				{
					ArithmeticException ex = new ArithmeticException("Divisor cannot be greater than dividend");
					throw ex;
				}
				
				o = n/d;
				System.out.println(o);
			
			
			System.out.println(dd[10]);
			
		}
		catch (ArithmeticException e) {
				System.out.println("there is some maths. error "+e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("array index out of bound");
		}
		catch (Exception e) {
			
			System.out.println("there is som technical error... "+e);
			
		}
		finally {
			sc.close();
		}
		//sum
		o =n+d;
		System.out.println(o);
		
	 

	}

}
