package example;

public class Caller  {

	public static void main(String[] args) {
		
		Test o =new Test();
		o.add(11, 22);
		o.mul(2.33, 44.5);
		
		o.alpha();
		
		
		
	}

}
