package example;

public class DCalc extends Calc {

	void mul(double d1 , double d2)
	{
		System.out.println(d1*d2);
	}
}
