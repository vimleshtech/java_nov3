package example;

public class Test extends DCalc {

	void alpha()	
	{
		System.out.println("test");
	}
}
