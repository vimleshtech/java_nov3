package example;

public class Calc {

static	void add(int a, int b)
	{
		System.out.println(a+b);
	}
static	void sub(int a, int b)
	{
		System.out.println(a-b);
	}
	
}
