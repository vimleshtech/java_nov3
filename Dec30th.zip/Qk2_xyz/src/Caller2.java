
public class Caller2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a =new A();
		a.test();//A
		
		B b =new B();
		b.test(); //B
		
		//overriding : Parent class object(ref) can call to child class methods/member
		a =b;
		a.test(); //B
		
		//or
		A oo =new B();
		oo.test();//B
		
	}

}
