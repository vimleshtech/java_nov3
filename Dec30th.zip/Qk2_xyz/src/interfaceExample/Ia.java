package interfaceExample;

public interface Ia {

	void add(int a, int b);
	int sub(int a, int b);
	
}
