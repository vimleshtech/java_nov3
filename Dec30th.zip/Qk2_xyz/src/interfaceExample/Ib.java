package interfaceExample;

public interface Ib {

	void mul();
	
}
