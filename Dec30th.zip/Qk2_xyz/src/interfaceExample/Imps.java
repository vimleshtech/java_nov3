package interfaceExample;

public class Imps implements Ia,Ib {

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
	
		System.out.println(a+b);
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		
	}

}
