import java.util.Scanner;

public class caller_xyz {

	public static void main(String[] args)
	{

		
		Scanner p=new Scanner(System.in);
		System.out.println("Plz enter the principle amount:");
		float principle=p.nextFloat();
		
		
		System.out.println("Plz enter the rate of inetrest:");
		float rate=p.nextFloat();
	
		
		xyz x=new xyz(principle,rate);		
		x.calc();
		x.disp();
		
		System.out.println("Plz enter the principle amount:");
		principle=p.nextFloat();
		
		
		System.out.println("Plz enter the rate of inetrest:");
		rate=p.nextFloat();
	
	

		System.out.println("Plz enter the time period:");
		int  time=p.nextInt();
		
		
		
		xyz x1=new xyz(principle,rate,time);		
		x.calc();
		x.disp();
		
		
		

	}

}
