
public class A {

	void test()
	{
		System.out.println("A");
	}
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
}
