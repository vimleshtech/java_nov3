
public class B  extends A{

	void test()
	{
		System.out.println("B");
	}
	void add(int a, int b,int c)
	{
		System.out.println(a+b);
	}
}
