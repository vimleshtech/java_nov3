import java.util.Scanner;

public class xyz 
{
	private float principle;
	private int time;
	private float rate;
	private float tamt;
	
	xyz(float principle, float rate)
	{
		this.principle = principle;
		this.rate = rate;
	}
	xyz(float principle, float rate,int time)
	{
		this.principle = principle;
		this.rate = rate;
		this.time = time;
			
	}
	
	public void calc()
	{
		if(time>0) {
			tamt=principle+(principle*time*rate/100);
		}
		else
		{
			tamt=principle+(principle*rate/100);
		}
				
	}
	
	public void disp()
	{
		System.out.println("Principle amount is: "+principle);
		System.out.println("Rate of interest is: "+rate);
		if(time>0)
			System.out.println("Time duration is: "+time);
		System.out.println("Total amount is: "+tamt);
	}
}
