package absExample;

public abstract class A {
	
	abstract void add(int a, int b);
	void sub(int a, int b) 
	{
		System.out.println(a-b);
	}
	

}
