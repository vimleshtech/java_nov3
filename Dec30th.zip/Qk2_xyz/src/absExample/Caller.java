package absExample;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A o =new Child();
		o.add(11, 22);
		o.sub(3, 4);
		
	}

}
