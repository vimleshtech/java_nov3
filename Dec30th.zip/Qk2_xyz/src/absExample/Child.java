package absExample;

public class Child extends A {

	@Override //Annotation (attribute)
	void add(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a+b);
	}

	
}
