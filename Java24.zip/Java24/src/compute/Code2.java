package compute;

public class Code2 {

	public static void main(String[] args) {
	
		int hs,es,cs,ms;
		int total;
		double avg;
		
		hs =66;
		es =89;
		ms =50;
		cs =90;
		
		total = hs+es+cs+ms;
		avg = total/4;
		
		System.out.println("total score is :"+total);
		System.out.println("average score "+avg);
		
		//grade 
		if(avg>=80)
		{
			System.out.println("A");
		}
		else if(avg>=60)
		{
			System.out.println("B");
		}
		else
		{
			System.out.println("C");
		}
		

	}

}
