package compute;

public class SquareRoot {

	public static void main(String[] args) {
		
		int n,cube;
		
		n=3;
		cube=n*n*n;
		
		System.out.println("Cube of Number " +cube);
		
	}

}
