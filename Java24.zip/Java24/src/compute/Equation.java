package compute;

public class Equation {

	public static void main(String[] args) {
		
		int a,aC,b,bC,c,cC,d,dC;
		
		a=2;
		aC=a*a*a;
		
		b=3;
		bC=b*b*b;
		
		c=4;
		cC=c*c*c;
		
		d=5;
		dC=d*d*d;
		
		
		if(aC + bC +cC == dC)
		{
			System.out.println("Satisfied");
			
		}
		else
		{
			System.out.println("Not Satisfied");
			
			
		}
				
		
		
	}

}
