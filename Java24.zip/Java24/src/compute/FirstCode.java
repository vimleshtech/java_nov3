package compute;

public class FirstCode{
	
	public static void main(String[] arg)
	{
		
		int a,b,c;
		
		a =44;
		b =55;
		c =a+b;
		
		System.out.println(c);
		
		
	}
}
