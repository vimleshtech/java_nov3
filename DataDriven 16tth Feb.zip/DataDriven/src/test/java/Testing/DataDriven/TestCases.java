package Testing.DataDriven;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class TestCases {
	
  @Test(dataProvider = "dp")
  public void f(String  uid, String pwd) {
	  System.out.println(uid+"\t"+pwd);
	  
	  
  }

  @DataProvider
  public Object[][] dp() {
    
	  Object out[][] = ExcelReader.readExcel();
	  return out;
  }
}
