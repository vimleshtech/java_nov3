package Testing.DataDriven;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelReader {

	public static void main1(String[] args)
	{
		
		try
		{		
			FileInputStream fs =new FileInputStream("C:\\Users\\vkumar15\\Desktop\\Desktop - Raman\\Mydata.xls");
			HSSFWorkbook book = new HSSFWorkbook(fs);
			
			HSSFSheet sheet = book.getSheetAt(0);
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets(); //sheet count
			
			rc = sheet.getPhysicalNumberOfRows(); //row count
			
			cc = sheet.getRow(0).getPhysicalNumberOfCells(); //col count
			
			System.out.println(sc);
			System.out.println(rc);
			System.out.println(cc);
			
			
			for(int r=0; r<rc;r++)
			{
				HSSFRow row = sheet.getRow(r);
				
				HSSFCell cell = row.getCell(0);
				
				String uid,pwd;
				uid = cell.getStringCellValue();
				
				cell = row.getCell(1);
				pwd = cell.getStringCellValue();
				
				System.out.println(uid+"\t"+pwd);
				
			}
			
		
		}
		catch (Exception e) 
		{
			
		}
		
	}

	//public static void main(String[] args)
	public static String[][] readExcel()	
	{
		
		String data[][] = null;
		try
		{		
			FileInputStream fs =new FileInputStream("C:\\Users\\vkumar15\\Desktop\\Desktop - Raman\\Mydata.xls");
			HSSFWorkbook book = new HSSFWorkbook(fs);
			
			HSSFSheet sheet = book.getSheetAt(0);
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets(); //sheet count
			
			rc = sheet.getPhysicalNumberOfRows(); //row count
			
			cc = sheet.getRow(0).getPhysicalNumberOfCells(); //col count
			
			System.out.println(sc);
			System.out.println(rc);
			System.out.println(cc);
			
			
			data =new String[rc-1][cc];
			
			for(int r=1; r<rc;r++)
			{
				HSSFRow row = sheet.getRow(r);
				
				HSSFCell cell = row.getCell(0);
				
				String uid,pwd;
				uid = cell.getStringCellValue();
				
				cell = row.getCell(1);
				pwd = cell.getStringCellValue();
				
				//System.out.println(uid+"\t"+pwd);
				
				data[r-1][0] =uid;
				data[r-1][1] =pwd;
				
			}
			
		
		}
		catch (Exception e) 
		{
			
		}
		return data;
	}

	
}
