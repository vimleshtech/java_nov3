package example;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;



public class CollectionExample {

	public static void main(String[] args) {

		
		System.out.println(	Math.pow(2, 4));
		System.out.println(	Math.floorDiv(11, 2));

		Date d = new Date();
		System.out.println(d);

		
		//Exampl 1:
		ArrayList al =new ArrayList();
		al.add(11);
		al.add(true);
		al.add("test");
		al.add(5555.33f);
		
		
		System.out.println(al.size());
		System.out.println(al.get(1));
		
		al.remove(1);

		System.out.println(al.size());
		System.out.println(al.get(1));
		
		
		for(int i=0;i<al.size();i++)
			System.out.println(al.get(i));

		
		//Example 2:
		ArrayList<String> al1 =new ArrayList<String>();
		//al1.add(11);
		al1.add("sdksjhs");
		al1.add("sshgsc");
		

		//Example 3:
		ArrayList<Employee> el =new ArrayList<>();
		List<Employee> el1 =new ArrayList<>();
		
		//el.add(11);
		el.add(new Employee(101, "Raman", "Sinha", "raman@gmail.com"));
		el.add(new Employee(102, "Nitin", "Sinha", "raman@gmail.com"));
		el.add(new Employee(103, "Nitisha", "Sinha", "raman@gmail.com"));
		el.add(new Employee(104, "Jatin", "Sinha", "raman@gmail.com"));
		el.add(new Employee(105, "Divya", "Sinha", "raman@gmail.com"));
		
		
		for(Employee e : el)
		{
			System.out.println(e.getEid()+"\t"+e.getFname());
		}
		
		
		
		//HashMap
		HashMap map =new HashMap();
		map.put(101, "test2");
		map.put("e2", "test2");
		map.put("e3", "test2");
		
		System.out.println(map.get("e2"));
		System.out.println(map.get(101));
		
		///
		HashMap<Integer,Employee> m =new HashMap();
		//excel loop
		m.put(101, new Employee(101, "Raman1", "sinha", "abc@gmail.com"));
		
		m.put(102, new Employee(102, "Raman2", "sharma", "abc@gmail.com"));
		m.put(103, new Employee(103, "Raman3", "sinha", "abc@gmail.com"));
		
		//t1,t2,t2,t100
		
		
		System.out.println(m.get(102).getFname());
		System.out.println(m.get(102).eid);
		
		
		
		
		
		
		
	}

}
