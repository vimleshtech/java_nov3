package example;

public class UniaryOperator {

	static void compute(int a, int b, String s)
	{
		switch (s) {
		
		case "+":
			System.out.println(a+b);
			break;
		case "-":
			System.out.println(a-b);
			break;

			
		default:
			break;
		}
	}
	static void compute(String s,int a, int b )
	{
			System.out.println(a-b);
	
	}

	
	public static void main(String[] args) {
		
		
		compute(111,333,"+");
		//compute(111,333,"-");
		compute("-",333,333);
		
	}

}
