package example;

public class Test extends Employee {

	public Test(int eid, String fname, String lname, String email) {
		super(eid, fname, lname, email);
		// TODO Auto-generated constructor stub
	}

	int eid;
	
	public void fun1(int eid)
	{
		eid =1;
		this.eid =1;
		super.eid  =1;
		
	}
}
