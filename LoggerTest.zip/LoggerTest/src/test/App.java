package test;

import org.apache.log4j.Logger;

public class App 
{
	private final static Logger logger = Logger.getLogger(App.class);
	
    public static void main( String[] args )
    {
    	logger.info("Main is invoked");
    	
        System.out.println( "Hello World!" );
        
        
        div();
        add();
        
        logger.info("Code execution is completed");
        
    }
    
    public static void add()
    {
    	logger.info("add is invoked");
    	int a,b,c;
    	a =33;
    	b =44;
    	c =a+b;
    	
        System.out.println( "sum = "+c );
        
        logger.info("add is closed");
    }
    
    public static void div()
    {
    	logger.info("div is invoked");
    	int a,b,c;
    	a =33;
    	b =0;
    	try
    	{
	    	c =a/b;
	    	System.out.println( "div ="+  c);
    	
    	}
    	catch (Exception e) {
			// TODO: handle exception
    		
    		logger.fatal(e.toString());
		}
    	
    	
        
    }
    
    
}
