package example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		String str,nstr;
		System.out.println("enter string : ");
		str = sc.nextLine();
		
		
		nstr = str.toUpperCase();
		System.out.println(nstr);
		
		nstr = str.toLowerCase();		
		System.out.println(nstr);
		
		nstr = str.replace("a", "xy");//here a is old char and xy is new
		System.out.println(nstr);
				
		int l = str.length();
		System.out.println(l);
		//remove space then get count of char
		l = str.replace(" ", "").length();
		System.out.println(l);
		
		
		

		int ps = str.indexOf("m");
		System.out.println(ps);
		
		///raman sinha = aman
		nstr  = str.substring(1, 5);
		System.out.println(nstr);
		
		
		//
		if(str.startsWith("ra"))		
			System.out.println("start with ra");		
		else
			System.out.println("NOT START WITH RA");
		
		//
		if(str.endsWith("ra"))		
			System.out.println("end with ra");		
		else
			System.out.println("NOT ends WITH RA");
		
		//
		if(str.contains("ma"))		
			System.out.println("contains  ma");		
		else
			System.out.println("NOT contains ma");
		
		//  diff between  == or equals 
		if(str.equals("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.equalsIgnoreCase("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}

		//
		char c = str.charAt(1);
		System.out.println(c);
		
		//convert char to ASCII
		int n = c;
		System.out.println(n);
		
		//toCharArray()  , raman = {'r','a','m','a','n'}
		char b[] = str.toCharArray();
		for(char m : b)
		{
			System.out.println(m);
		}
		
		
		//split(), this is java code ={"this","is","java","code"}	
		String ss[] = str.split(" ");
		for(String m : ss)
		{
			System.out.println(m);
		}
		
		
		
		
		
	}

}
