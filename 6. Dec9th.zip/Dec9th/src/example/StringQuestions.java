package example;

public class StringQuestions {

	public static void main(String[] args) {

		String a="ab";
		StringBuilder s = new StringBuilder();
		s.append("sjhsgs");
		
		a = a+"cd";
		
		System.out.println(a);
		
		if(a=="abcd")
		{
			System.out.println("match with ==");
		}
		else
		{
			System.out.println("not match with ==");
		}
		//

		if(a.equals("abcd"))
		{
			System.out.println("match with fun");
		}
		else
		{
			System.out.println("not match with fun");
		}
		
		
		
	}

}
