package example;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Questions {

	static final Logger logger = Logger.getLogger(Questions.class);
	
	public static void main(String[] args) {
	
		logger.info("--------------------------");
		logger.info("main is started..");
	
		System.out.println("test");
		String str="2nd war is startinf in 02-10-1945, and this war was ended on 10-11-1945.";
		
		str = str.replace(",", " ").replace(".", " ");
		
		
		String a[] = str.split(" ");
		
		logger.info("before loop.");
		
		try
		{
			int nn=11/2;
			
			for(String b : a)
			{
				if(b.length()==10 )
				{
					if(b.charAt(5)=='-')
					{
						System.out.println(b.substring(6, b.length()));
					}
					
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
		}
		
		logger.debug("end of the code");

	}

}
