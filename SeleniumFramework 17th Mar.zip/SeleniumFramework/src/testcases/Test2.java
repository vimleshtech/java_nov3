package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.AfterSuite;

public class Test2 {
  @Test
  public void f() {
	  System.out.println("test 2 f");
  }
  @Test
  public void f2() {
	  System.out.println("f2");
  }
  
  
  @AfterClass
  public void afterClass() {
  }

  @AfterTest
  public void afterTest() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
