package webelements;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementFinder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();		
		driver.get("https://www.google.com");
		
		
		driver.findElement(By.linkText("Gmail")).click();
		driver.findElement(By.xpath("/html/body/nav/div/a[2]")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.id("identifierId")).clear();
		driver.findElement(By.id("identifierId")).sendKeys("vimlesh073@gmail.com");
		
		driver.findElement(By.id("identifierNext")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("vimlesh073@gmail.com");
		
		driver.findElement(By.id("passwordNext")).click();
		
		
		String s = driver.findElement(By.xpath("//*[@id=\"password\"]/div[2]/div[2]/div")).getText();
		
		s = driver.findElement(By.cssSelector("#password > div.LXRPh > div.dEOOab.RxsGPe > div")).getText();
		
		
		
		
		System.out.println(s);
		
		
		
		
	//	//*[@id="identifierId"]
	//	identifierId
		//*[@name='identifierId']
		
		

	}

}
