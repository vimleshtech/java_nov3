package exampleConstructor;

public class Calc {

	//constructor 
	Calc()
	{
		System.out.println("object is created");
	}
	
	//with argument 
	Calc(String country)
	{
		if(country.equals("india"))
		{
			System.out.println("welcome..., new copy of class is created");
		}
		else 
		{
			System.out.println("New User..., new copy of class is created");
		}
		
	}
	//copy constructor 
	Calc(Calc o)
	{
		System.out.println("copy cons has been called");
	}
	
	//normal function/method
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
}
