package exampleConstructor;

public class Caller {

	public static void main(String[] args) {

		Calc o = new Calc();
		//o.add(11, 22);

		Calc o2 =new Calc("us");

		//
		Calc o3 =new Calc(o);
		
		
	}

}
