package examplej5;


import java.util.Scanner;

public class Student {

	private	int  rno;	
	private	String name;
	private	String add;
	private	String city;
	private	String country;
	
	public void input()
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter rno");
		rno = sc.nextInt();
		
		System.out.println("enter name ");
		name = sc.next();
		
		
		System.out.println("enter add ");
		add = sc.next();
		
		System.out.println("enter city ");
		city = sc.next();
		
		
		System.out.println("enter country ");
		country = sc.next();
		

	}
	public int getrno()
	{
			return rno;
	}
	public void disp()
	{
		System.out.println("rno : "+rno);
		System.out.println("name : "+name);
		System.out.println("add : "+add);
		System.out.println("city : "+city);
		System.out.println("country : "+country);
		
		
	}
	
}

