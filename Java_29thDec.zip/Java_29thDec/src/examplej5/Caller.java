package examplej5;

import java.util.Scanner;

public class Caller {

	public static void main(String[] args) {
		
		Student s[] =new Student[4];
		
		for(int i=0; i<4;i++)
		{
			s[i] = new Student();
			s[i].input();
		}

		//sorting 
		for(int j=0; j<4;j++)
		{
			for(int k=j+1; k<4;k++)
			{
				if(s[j].getrno() > s[k].getrno())
				{
					Student t = s[j];
					s[j] = s[k];
					s[k] = t;
				}
			}	
		}
		
		//show all 
		//for(Student ss : s)
		//	ss.disp();
		
		//search 
		Scanner sc = new Scanner(System.in);
		System.out.println("enter eid : ");
		int rid = sc.nextInt();
		
		for(Student ss : s)
		{
			if(ss.getrno() == rid)
				ss.disp();
		}		
		
	}

}
