package example;

import java.util.Scanner;

public class Taxpayer {

	private	String pan;	
	private	String name;
	private double income;
	private double  tax;
	
	public void input()
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter pan no.");
		pan = sc.next();

		if(pan.length()<10 )
		{
			System.out.println("enter the pan again : ");
		}
		
		System.out.println("enter name ");
		name = sc.next();
		
		
		System.out.println("enter income ");
		income = sc.nextDouble();

	}
	public void calc()
	{
		if(income<=100000)
		{
				tax =0;			
		}
		else if (income<=200000)
		{
				tax = (income-100000)*.10;				
		}
		else if (income<=500000)
		{
			tax =10000+(income-200000)*.15;
			
			//		300000 =45000 
			//		15000+10000 
		}
		else
		{
			tax =55000+(income-500000)*.20;
		}
	}
	public void disp()
	{
		System.out.println("PAN : "+pan);
		System.out.println("name : "+name);
		System.out.println("income : "+income);
		System.out.println("tax : "+tax);
		
	}
	
}
