package example;

public class Startup {

	public static void main(String[] args) {

		/*
		Taxpayer p =new Taxpayer();
		p.input();
		p.calc();
		p.disp();
		*/
		Taxpayer p[] =new Taxpayer[3];
		
		for(int i=0;i<3;i++)
		{
			p[i] = new Taxpayer();
			p[i].input();
			p[i].calc();
			
		}
		
		for(Taxpayer o : p)
			o.disp();
		
		

	}

}
