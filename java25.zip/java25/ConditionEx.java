package java25;

public class ConditionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=11;
		
		
		if(a%2==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}
		
		//
		int b=33,c=44;
		
		if(a>b && a>c)
		{
			System.out.println("a is gt");
		}
		else if(b>a && b>c)
		{
			System.out.println(" b is gt");
		}
		else
		{
			System.out.println("c is gt");
		}
		
	}

}
