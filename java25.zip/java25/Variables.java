package java25;

public class Variables {

	//global variable
	static int c;  //static variable
	int m;  //instance variable 
	
	
	public static void main(String[] args) {

		//local variable 
		int a,b;
		a =44;
		b =44;
				
		//c =a+b;//global varibale
		//add();
		
		//create object
		Variables v1 =new Variables();
		Variables v2 =new Variables();
		
		v1.m =10;
		v2.m =100;
		
		v1.c =10;		
		c =100;
		
		System.out.println(v1.m); //10
		System.out.println(v2.m);//100
		
		System.out.println(v1.c);//100
		System.out.println(v2.c);//100
		
		//
		int i=0,j=0;
		
		System.out.println(i++);//0
		System.out.println(++j);//1
		
		System.out.println(i);//1
		System.out.println(j);//1
		
		
	}
	public static void add()
	{
		
		//int c =a+b;
		//c =111; //global varibale 
		
		System.out.println(c);
	}

}
