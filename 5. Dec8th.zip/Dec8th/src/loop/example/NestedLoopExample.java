package loop.example;

public class NestedLoopExample {

	public static void main(String[] args) {

		/*
		 * r=0 c =0 1 2 
		 * r=1 c =0 1 2 
		 * ..
		 * ..
		 */
		
		for(int r=0; r<4;r++) //rows  =4 
		{			
			for(int c=0; c<3; c++) // cols = 3
			{
				System.out.print(c);
			}
			System.out.println();
		}
		//pattern
		for(int r=0; r<4;r++) //rows  =4 
		{			
			for(int c=0; c<3; c++) // cols = 3
			{
				System.out.print("*");
			}
			System.out.println();
		}

		//
		for(int r=0; r<4;r++) //rows  =4 
		{			
			for(int c=0; c<=r; c++) // cols = 3
			{
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

}
