package loop.example;

public class DoWhileExample {

	public static void main(String[] args) {
		
		//First execute then check the condition 
		//Do while will execute at least one time
		
		int i=0;
		do
		{
			System.out.println(i);
			i++;
			
		}while(i<0);
		
		
	}

}
