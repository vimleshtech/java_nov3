package loop.example;

public class AdvanceLoopExample {

	public static void main(String[] args) {

		
		int n[] = {111,222,333,444,1};
		
		// :  from 0th index to len-1
		//foreach loop is forward only 
		for(int d : n)
		{
			System.out.println(d);
		}
		

	}

}
