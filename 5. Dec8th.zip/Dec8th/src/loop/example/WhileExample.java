package loop.example;

public class WhileExample {

	public static void main(String[] args) {
		
		int i=1; //init
		
		while(i<10) // condition 
		{
			System.out.println(i);
			i++;
		}
		
		//
		i=1;
		while(i<10) // condition 
		{
			System.out.print(i);
			i++;
		}
		
		//print in reverse order
		i=10;
		while(i>0) // condition 
		{
			System.out.println(i);
			i--;
		}
		
		//wap to print all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i+=2; //i=i+2
		}
		
	
		//wap to get sum of all even and odd numbers between 1 to 100
		
		int se=0,so=0;
		i=1;
		while(i<=100)
		{
			if(i%2==0)
				se =se+i;
			else
				so=so+i;
			i++;
		}
		System.out.println(se);
		System.out.println(so);

	}

}
