package array.example;

import java.util.Scanner;

public class Table {

	public static void main(String[] args) {
		
		int n, num,table;
		
		
		Scanner sc =new Scanner(System.in);
		
		
		System.out.println("enter a number");
		n=sc.nextInt();
		System.out.println("enter a number");
		num=sc.nextInt();
		int i =1;
		while(i<=n)
		{
			table=num*i;
			System.out.println(table);
			
			i++;
		}
		
		
	}

}
