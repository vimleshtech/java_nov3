package array.example;

import java.util.Scanner;

public class SingleDArray {

	public static void main(String[] args) {
		
		int n[] =new int[4];
		n[0] =33;
		n[1] =133;
		n[2] =533;
		n[3] =330;
		
		
		//read first element by index
		System.out.println(n[0]);
		
		//get sum of all numbers
		int sum=0;
		//read all element
		for(int m:n)
		{
			System.out.println(m);
			sum = sum+m;
		}
		System.out.println(sum);
		

		//fill data in array from user
		int d[] = new int[3];
		Scanner sc =new Scanner(System.in);
		
		for(int i=0; i<3;i++)
		{
			System.out.println("enter data : ");
			d[i] = sc.nextInt();
		}
		
		for(int i =0; i<3;i++)
		{
			System.out.println(d[i]);
		
		}
		
	}

}
