package array.example;

import java.util.Scanner;

public class sumofnaturalNo {

	public static void main(String[] args) {
		
		
		int sum=0,num=0;
		float avg=0f;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number:");
		num = sc.nextInt();
		
		for (int i=1;i<num;i++)
		{
			System.out.println(i);
			sum=sum+i;
			avg=sum/num;
			
		}
		System.out.println(sum);
		System.out.println(avg);
		
		
		
	}

}
