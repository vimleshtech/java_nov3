package array.example;

import java.util.Scanner;

public class Oddnumbers {

	public static void main(String[] args) {
		
		int num=0,se=0,so=0;
		float avg_even=0f, avg_odd=0f;
		
        Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Number:");
		num = sc.nextInt();
		
		int Count_odd=0,count_even=0;
		
		for (int i=1; i<=num;i++)
		{
	
				if(i%2==0)
				{
					
					se =se+i;
				    System.out.println("Even Numbers:" +i);
				    count_even++;
				}
				else
				{
					System.out.println("Odd Numbers:" +i);
					so=so+i;
					Count_odd++;
				}
				
				
	  }
		avg_odd=so/Count_odd;
		avg_even=se/count_even;
		
		System.out.println("Sum of Even:" +se);
		System.out.println("Sum of Odd:" +so);
		
		System.out.println("Avg of Even:" +avg_even);
		System.out.println("Avg of Odd:" +avg_odd);
		
		}
		
		
		
	}


